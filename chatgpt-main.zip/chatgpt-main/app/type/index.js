export const TYPE = {
  PERSON: 'person',
  BOT: 'bot'
};