import axios from 'axios';
import API from './request';

export const createAnswer = ({ text, controller }) => {

  const data = {
    "model": "gpt-3.5-turbo",
    "messages": [{"role": "user", "content": text}],
    "temperature": 0.7
  };

  return axios.post('https://api.openai.com/v1/chat/completions',data, {
    headers: {
      Authorization: 'Bearer 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'
    },
    signal: controller?.signal,
});;
}